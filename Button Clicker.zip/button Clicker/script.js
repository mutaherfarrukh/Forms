function SignClick(){
    alert("Ninja was liked")
}

function Logout(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}






